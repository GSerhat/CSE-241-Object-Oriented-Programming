#include "CPU.h" // called CPU.h
#include "CPUProgram.h" // called CPUProgram.h
#include "Memory.h"
#include "Computer.h"
#include <iostream> // for cin cout
#include <cstdlib> 
#include <string> // for string type

using namespace std;


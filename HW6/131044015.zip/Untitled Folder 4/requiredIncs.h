#include "CPU.h" // called CPU.h
#include "CPUProgramDyn.h" // called CPUProgram.h
#include "Memory.h"
#include "Computer.h"
#include <iostream> // for cin cout
#include <cstdlib> 
#include <string> // for string type

//using namespace std;
using Program :: CPUProgramDyn;
